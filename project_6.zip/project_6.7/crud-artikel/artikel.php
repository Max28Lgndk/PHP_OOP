<?php
include "../database/db_connect.php";
include "../database/workforce.php";

$database = new Workforce();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project 6</title>
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../fontawesome/css/all.min.css">
    <link rel="stylesheet" href="../css/magnific-popup.css">
    <link rel="stylesheet" href="../css/style.css">

</head>
<body>
<header class="tm-site-header">
    <h1 class="tm-mt-0 tm-mb-15"><span class="tm-color-primary">Nederlands</span> <span class="tm-color-gray-2">Nieuws</span></h1>
    <em class="tm-tagline tm-color-light-gray">Uw nieuws op één plek</em>
</header>

<!-- Photo banner 400 px height -->
<div id="tm-video-container">
    <img id="tm-video" src="../img/Skyline-Rotterdam.jpg">
    <i id="tm-video-control-button" class="fas fa-pause"></i>
</div>
<!-- read Form -->
<div class="artikel">
    <?php require_once "../database/read.php";?>
</div>
<footer class="tm-footer">
</footer>

<script src="../js/jquery-3.4.1.min.js"></script>
<script src="../js/imagesloaded.pkgd.min.js"></script>
<script src="../js/isotope.pkgd.min.js"></script>
<script src="../js/jquery.magnific-popup.min.js"></script>
<script src="../js/templatemo-script.js"></script>
</body>
</html>