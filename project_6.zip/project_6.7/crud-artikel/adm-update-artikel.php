
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Project 6</title>
        <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="../fontawesome/css/all.min.css">
        <link rel="stylesheet" href="../css/magnific-popup.css">
        <link rel="stylesheet" href="../css/style.css">

    </head>
    <body>
    <header class="tm-site-header">
        <h1 class="tm-mt-0 tm-mb-15"><span class="tm-color-primary">ADMIN Nederlands</span> <span class="tm-color-gray-2">Nieuws</span></h1>
        <em class="tm-tagline tm-color-light-gray">Uw nieuws op één plek</em>
    </header>

    <!-- Photo banner 400 px height -->
    <div id="tm-video-container">
        <img id="tm-video" src="../img/Skyline-Rotterdam.jpg">
        <i id="tm-video-control-button" class="fas fa-pause"></i>
    </div>
    <div class="tm-container">
        <nav class="tm-main-nav">
            <ul id="inline-popups">
                <li class="tm-nav-item">
                    <a href="#gallery" data-effect="mfp-move-from-top" class="tm-nav-link" id="tm-gallery-link">
                        Artikels
                        <i class="far fa-3x fa-images"></i>
                    </a>
                </li>
                <li class="tm-nav-item">
                    <a href="#intro" data-effect="mfp-move-from-top" class="tm-nav-link">
                        Update
                        <i class="fas fa-3x fa-water"></i>
                    </a>
                </li>
                <li class="tm-nav-item">
                    <a href="#create-artikel" data-effect="mfp-move-from-top" class="tm-nav-link">
                        create
                        <i class="far fa-3x fa-smile"></i>
                    </a>
                </li>
                <li class="tm-nav-item">
                    <a href="#contact" data-effect="mfp-move-from-top" class="tm-nav-link">
                        Delete
                        <i class="far fa-3x fa-comments"></i>
                    </a>
                </li>
            </ul>
        </nav>

        <!-- update  -->
        <div id="intro" class="popup mfp-with-anim mfp-hide tm-bg-gray">
            <a href="#" class="tm-close-popup">
                return home
                <i class="fas fa-times"></i>
            </a>
            <p> WERKT FUCKING NIET GEEEN IDEEE WAT ER FOUT GAAT FFFFFFFFFFFFFFFFFFFFFFFFF</p>
            <!-- update artikel form -->
            <div class="container">
                <?php
                if(isset($_GET['msg']))
                    echo "<h1>".$_GET['msg']."</h1>";
                ?>
                <form action="" method="post">
                    ID<br>
                    <label>
                        <input type="number" name="id" size="50">
                    </label><br><br>
                    Titel<br>
                    <label>
                        <input type="text" name="txtTitel" size="50">
                    </label><br><br>

                    Content<br>
                    <label>
                        <input type="text" name="txtContent" size="100">
                    </label><br><br>

                    <input type="submit" name="btnSubmit" value="Voer het product in">

                </form>
        </div>
        <!-- Artikel page -->
        <div id="gallery" class="popup mfp-with-anim mfp-hide tm-bg-gray">
            <a href="#" class="tm-close-popup">
                return home
                <i class="fas fa-times"></i>
            </a>
            <div class="tm-row tm-gallery-row">
                <div class="tm-gallery">
                    <div class="tm-gallery-container">
                        <div class="tm-gallery-item" style="position: absolute; margin-left: 0%; margin-bottom: -15px; border: orange 2px">
                            <p>FFuck dit kankaaaaaa aaaaaaaaaer ding mannnn</p>
                        </div>
                        <div class="tm-gallery-item" style="position: absolute; margin-left: 30%; margin-bottom: -15px">
                            <p>Fffuck dit kanker ding mannnn</p>
                        </div>
                        <div class="tm-gallery-item" style="position: absolute; margin-left: 60%; margin-bottom: 0px">
                            <p>Beter heb ik hemm</p>
                        </div>
                        <div class="tm-gallery-item" style="position: absolute; margin-left: 0%; margin-top: 250px">
                            <p>SAAAAAAAAAAAAAAAA</p>
                        </div>
                        <div class="tm-gallery-item" style="position: absolute; margin-left: 30%; margin-top: -15px">
                            <p>SAAAAAAAAAAAAAAAA</p>
                        </div>
                        <div class="tm-gallery-item" style="position: absolute; margin-left: 60%; margin-top: -15px">
                            <p>SAAAAAAAAAAAAAAAA</p>
                        </div>
                    </div>
                </div>
                <!-- Gallery navigation and description -->
                <div class="tm-col tm-gallery-right">
                    <h2 class="tm-color-primary tm-mt-35 tm-page-title">Artikels</h2>
                    <div class="tm-gallery-right-inner">
                        <ul class="tm-gallery-links">

                            <p>
                                Hier kan je alle artikelen vinden, deze worden elke dag veranderd maar
                                u kunt de oude nogsteeds opzoeken
                            </p>
                            <p>
                                Proin lacus enim, finibus sed magna a,
                                molestie lacinia est. Maecenas id dolor
                                lorem. Donec sodales ex velit.
                            </p>
                    </div>
                </div>
            </div>
        </div>
        <!-- PROFILE PAGE -->
        <div id="create-artikel" class="popup mfp-with-anim mfp-hide tm-bg-gray">
            <a href="#" class="tm-close-popup">
                return home
                <i class="fas fa-times"></i>
            </a>
            <div class="tm-testimonials-inner">
                <h2 class="tm-color-gray tm-testimonial-col tm-page-title">Artikel aanmaken</h2>
                <div class="tm-row tm-testimonial-row">
                    <!-- Upper part -->
                    <p>Voer hier het artikel informatie in.</p>
                    <!-- Contact Form-->
                    <form id="artikel-form" action="../database/create-artikelen.php" method="POST" class="tm-contact-form">
                        <div class="form-group">
                            <input type="text" name="txtTitel" class="form-control rounded-0" placeholder="Titel" required />
                        </div>
                        <div class="form-group">
                            <textarea rows="8" name="txtContent" class="form-control rounded-0" placeholder="Content" required=></textarea>
                        </div>

                        <div class="form-group tm-text-right">
                            <button type="submit" class="tm-btn tm-btn-primary">Plaats artikel</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- Contact Page -->
    <div id="contact" class="popup mfp-with-anim mfp-hide tm-bg-gray">
        <a href="#" class="tm-close-popup">
            return home
            <i class="fas fa-times"></i>
        </a>
        <h2 class="tm-contact-col tm-color-primary tm-page-title tm-mb-40">Contact Us</h2>
        <div class="tm-row tm-contact-row">
            <div class="tm-col tm-contact-col">
                <!-- Contact Form-->
                <form id="contact-form" action="" method="POST" class="tm-contact-form">
                    <div class="form-group">
                        <input type="text" name="name" class="form-control rounded-0" placeholder="Full Name" required />
                    </div>
                    <div class="form-group">
                        <input type="email" name="email" class="form-control rounded-0" placeholder="Email" required />
                    </div>
                    <div class="form-group">
                        <select class="form-control" id="contact-select" name="inquiry">
                            <option value="-">Subject</option>
                            <option value="sales">Sales &amp; Marketing</option>
                            <option value="creative">Creative Design</option>
                            <option value="uiux">UI / UX</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <textarea rows="8" name="message" class="form-control rounded-0" placeholder="Message" required=></textarea>
                    </div>

                    <div class="form-group tm-text-right">
                        <button type="submit" class="tm-btn tm-btn-primary">Send it now</button>
                    </div>
                </form>
            </div>
            <div class="tm-col tm-contact-col tm-contact-col-r">
                <!-- Map -->
                <div class="mapouter tm-mb-40">
                    <div class="gmap_canvas">
                        <iframe width="100%" height="520" id="gmap_canvas"
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4528.850674645962!2d4.546321648786219!3d51.95182740711822!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c5cd3c66c593ad%3A0x37ff53ecda71ac07!2sTechniek%20College%20Rotterdam!5e0!3m2!1snl!2snl!4v1642757542551!5m2!1snl!2snl"
                                frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
                    </div>
                </div>

                <!-- Address -->
                <address class="tm-mb-40">
                    Alexanderstraat 1088 ofso
                </address>

                <!-- Links -->
                <ul class="tm-contact-links">
                    <li>
                        <a href="tel:0100200340">
                            <i class="fas fa-phone tm-contact-link-icon"></i>
                            Tel: 010-020-0340
                        </a>
                    </li>
                    <li>
                        <a href="mailto:info@company.com">
                            <i class="fas fa-at tm-contact-link-icon"></i>
                            Email: info@company.com
                        </a>
                    </li>
                    <li>
                        <a href="https://www.company.com">
                            <i class="fas fa-link tm-contact-link-icon"></i>
                            URL: www.company.com
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<footer class="tm-footer">
</footer>

<script src="../js/jquery-3.4.1.min.js"></script>
<script src="../js/imagesloaded.pkgd.min.js"></script>
<script src="../js/isotope.pkgd.min.js"></script>
<script src="../js/jquery.magnific-popup.min.js"></script>
<script src="../js/templatemo-script.js"></script>
</body>
</html>