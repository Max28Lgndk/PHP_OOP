<?php

if(isset($_POST["submit"]))
{

    //Data pakken
    $uid = $_POST["uid"];
    $pwd = $_POST["pwd"];
    $pwdRepeat = $_POST["pwdRepeat"];
    $email = $_POST["email"];

    //Constructor runnen
    include "../classes/dbh.classes.php";
    include "../classes/signup.classes.php";
    include "../classes/signup-contr.classes.php";
    $signup = new SignupContrl($uid, $pwd, $pwdRepeat, $email);

    //Running errors
    $signup->signupUser();

    //Terug gaan naar front-page
    header("location: ../home.php?error=none");

}
