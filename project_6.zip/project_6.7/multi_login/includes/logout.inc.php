<?php
session_start();
session_unset();
session_destroy();

//Terug gaan naar front-page
header("location: ../index.php");




