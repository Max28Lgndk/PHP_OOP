<!--<html lang="nl">-->
<!--<head>-->
<!--    <meta name="author" content="Milan Groeneweg">-->
<!--    <meta charset="UTF-8">-->
<!--    <title></title>-->
<!--</head>-->
<!--</html>-->
<?php
//session_start();
//
////connectie met database
//$db= mysqli_connect('localhost', 'root', '', 'database');
//
////variabelen waardes
//$gebruikersnaam = "";
//$email = "";
//$errors = array();
//
////registreer functie oproepen als de registreer button wordt aangeklikt (register_btn)
//if (isset($_POST['register_btn'])){
//    register();
//}
//
////gebruiker registreren
//function register()
//{
//    //variabelen oproepen met 'global' om deze in de functie te kunnen oproepen
//    global $db, $errors, $gebruikersnaam, $email;
//
//    //defineren
//    $gebruikersnaam = e($_POST['gebruikersnaam']);
//    $email = e($_POST['email']);
//    $wachtwoord_1 = e($_POST['wachtwoord_1']);
//    $wachtwoord_2 = e($_POST['wachtwoord_2']);
//
//
//    //checkt of het forum goed is ingevuld checkt voor evt errors
//    if (empty($gebruikersnaam)) {
//        array_push($errors, "Gebruikersnaam is verplicht");
//    }
//    if (empty($email)) {
//        array_push($errors, "Een email is verplicht");
//    }
//    if (empty($wachtwoord_1)) {
//        array_push($errors, "Wachtwoord is verplicht");
//    }
//    if (empty($wachtwoord_2)) {
//        array_push($errors, "Wachtwoorden komen niet een overeen");
//    }
//
//    //als er geen errors zijn, registreer gebruiker
//    if (count($errors) == 0) {
//        $wachtwoord = md5($wachtwoord_1);//Dit 'encrypt' het wachtwoord voordat het naar de database wordt gestuurd
//
//        if (isset($_POST['gebruiker_type'])) {
//            $gebruiker_type = e($_POST['gebruiker_type']);
//            $query = "INSERT INTO gebruikers (gebruikersnaam, email, gebruiker_type, wachtwoord)
//                      VALUES('$gebruikersnaam', '$email','$gebruiker_type', '$wachtwoord')";
//            mysqli_query($db, $query);
//            $_SESSION['success'] = "Nieuwe gebruiker succesvol aangemaakt!";
//            header('location: ../Project_P5/home.php');
//        }else{
//            $query = "INSERT INTO gebruikers (gebruikersnaam, email, gebruiker_type, wachtwoord )
//                      VALUES('$gebruikersnaam', '$email', 'gebruiker', '$wachtwoord')";
//            mysqli_query($db, $query);
//
//            //id van de gemaakte gebruiker ophalen
//            $logged_in_gebruiker_id = mysqli_insert_id($db);
//
//            $_SESSION['gebruiker'] = getUserByID($logged_in_gebruiker_id); //ingelogde gebruiker in session zetten
//            $_SESSION['success'] = "U bent nu ingelogd";
//            header('location: ../Project_P5/home.php');
//        }
//    }
//}
////functies
//function getUserById($id){
//    global $db;
//    $query = "SELECT * FROM gebruikers Where id=" . $id;
//    $result = mysqli_query($db, $query);
//
//    $gebruiker = mysqli_fetch_assoc($result);
//    return $gebruiker;
//}
//
//function e($val){
//    global $db;
//    return mysqli_real_escape_string($db, trim($val));
//}
//
//function display_error() {
//    global $errors;
//
//    if(count($errors) >0){
//        echo '<div class="error">';
//            foreach ($errors as $error){
//                echo $error .'<br>';
//            }
//            echo'</div>';
//    }
//}
//function isLoggedIn()
//{
//    if (isset($_SESSION['gebruiker'])) {
//        return true;
//    }else{
//        return false;
//    }
//}
////loguit functie je wordt automatisch doorverwezen naar: login.php (loginscherm)
//if (isset($_GET['logout'])) {
//    session_destroy();
//    unset($_SESSION['gebruiker']);
//    header("location: login.php");
//}
//// de login() functie wordt opgeroepen als de login knop wordt aangeklikt
//if (isset($_POST['login_btn'])) {
//    login();
//}
//
//// gebruiker inloggen
//function login(){
//    global $db, $gebruikersnaam, $errors;
//
//    // formulier gegevens ophalen
//    $gebruikersnaam = e($_POST['gebruikersnaam']);
//    $wachtwoord = e($_POST['wachtwoord']);
//
//    // met if statements checken of het formulier goed is ingevuld, zo niet dan een toepassende error weergeven
//    if (empty($gebruikersnaam)) {
//        array_push($errors, "Gebruikersnaam is verplicht");
//    }
//    if (empty($wachtwoord)) {
//        array_push($errors, "Wachtwoord is verplicht");
//    }
//
//    // login proberen als er geen fouten zijn (dit checken dmv een if statement)
//    if (count($errors) == 0) {
//        $wachtwoord = md5($wachtwoord);
//
//        $query = "SELECT * FROM gebruikers WHERE gebruikersnaam='$gebruikersnaam' AND wachtwoord='$wachtwoord' LIMIT 1";
//        $results = mysqli_query($db, $query);
//
//        if (mysqli_num_rows($results) == 1) { // gebruiker gevonden
//            // checken of het een admin of gebruiker is(heeft het geen gebruiker type=gebruiker, wel= admin)
//            $logged_in_gebruiker = mysqli_fetch_assoc($results);
//            if ($logged_in_gebruiker['gebruiker_type'] == 'admin') {
//
//                $_SESSION['gebruiker'] = $logged_in_gebruiker;
//                $_SESSION['success']  = "U bent nu ingelogd";
//                header('location: admin/home.php');
//            }else{
//                $_SESSION['user'] = $logged_in_gebruiker;
//                $_SESSION['success']  = "U bent nu ingelogd";
//                header('location: ../Project_P5/home.php');
//            }
//        }else {
//            array_push($errors, "Verkeerde gebruikersnaam/wachtwoord combinatie");
//        }
//    }
//}
////function voor gebruiker type admin
//function isAdmin()
//{
//    if (isset($_SESSION['gebruiker']) && $_SESSION['gebruiker']['gebruiker_type'] == 'admin' ) {
//        return true;
//    }else{
//        return false;
//    }
//}