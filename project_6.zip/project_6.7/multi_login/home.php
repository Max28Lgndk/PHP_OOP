<?php
include "../database/db_connect.php";
include "../database/workforce.php";

$database = new Workforce();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project 6</title>
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../fontawesome/css/all.min.css">
    <link rel="stylesheet" href="../css/magnific-popup.css">
    <link rel="stylesheet" href="../css/style.css">

</head>
<body>
    <header class="tm-site-header">
        <h1 class="tm-mt-0 tm-mb-15"><span class="tm-color-primary">Nederlands</span> <span class="tm-color-gray-2">Nieuws</span></h1>
        <em class="tm-tagline tm-color-light-gray">Uw nieuws op één plek</em>
    </header>

    <!-- Photo banner 400 px height -->
    <div id="tm-video-container">
        <img id="tm-video" src="../img/Skyline-Rotterdam.jpg">
        <i id="tm-video-control-button" class="fas fa-pause"></i>
    </div>
    <div class="tm-container">
        <nav class="tm-main-nav">
            <ul id="inline-popups">
                <li class="tm-nav-item">
                    <a href="#intro" data-effect="mfp-move-from-top" class="tm-nav-link">
                        Over ons
                        <i class="fas fa-3x fa-water"></i>
                    </a>
                </li>
                <li class="tm-nav-item">
                    <a href="#artikels" data-effect="mfp-move-from-top" class="tm-nav-link" id="tm-gallery-link">
                        Artikelen
                        <i class="far fa-3x fa-images"></i>
                    </a>
                </li>
                <li class="tm-nav-item">
                    <a href="#testimonials" data-effect="mfp-move-from-top" class="tm-nav-link">
                        Aanmelden
                        <i class="far fa-3x fa-smile"></i>
                    </a>
                </li>
                <li class="tm-nav-item">
                    <a href="#contact" data-effect="mfp-move-from-top" class="tm-nav-link">
                        Contact
                        <i class="far fa-3x fa-comments"></i>
                    </a>
                </li>
            </ul>
        </nav>

        <!-- ABout us -->
        <div id="intro" class="popup mfp-with-anim mfp-hide tm-bg-gray">
            <a href="#" class="tm-close-popup">
                return home
                <i class="fas fa-times"></i>
            </a>
            <div class="tm-row tm-intro-row">
                <img src="../img/Intro.jpg" alt="Image" class="tm-intro-img">t
                <div class="tm-col tm-bg-white tm-intro-pad">
                    <h2 class="tm-color-primary tm-page-title">Introducing Nederlands Nieuws</h2>
                    <div class="tm-row tm-content-row">
                        <div class="tm-col-6 tm-intro-col-l">
                            <p>
                                Welkom bij Nederlands Nieuws, uw nummer één bron voor al uw Nederlandse nieuws.
                                We zijn hier om u het allerbeste in nieuwsartikelen te geven,
                                met een focus op zo snel mogelijk.
                                Zo nauwkeurig mogelijk en je beste nieuwsaanbieder te zijn.
                            </p>
                            <p class="tm-mb-0">
                                We hopen dat u net zoveel van ons nieuws geniet als wij het u graag aanbieden.
                                Als u vragen of opmerkingen heeft, aarzel dan niet om contact met ons op te nemen.
                            </p>
                        </div>
                        <div>
                            <p class="tm-mb-80">
                                Volgende pagina brengt je naar onze nieuws artikelen.
                            </p>
                            <div class="tm-text-center">
                                <a href="#" class="tm-btn tm-btn-primary mfp-prevent-close tm-btn-next">
                                    Volgende pagina
                                </a>
                            </div>                            
                        </div>
                    </div>
                </div>                
            </div> 
        </div>
        <!-- Artikel page -->
        <div id="artikels" class="popup mfp-with-anim mfp-hide tm-bg-gray">
            <a href="#" class="tm-close-popup">
                return home
                <i class="fas fa-times"></i>
            </a>
            <div class="tm-row tm-gallery-row">
                <div class="tm-gallery">
                    <div class="tm-gallery-container">
                        <?php foreach($database->getArtikelen() as $artikel) { ?>

                            <div class="tm-gallery-item" ><?php echo $artikel->titel;
                                ?>
                                <a href="../crud-artikel/artikel.php?id=<?php echo $artikel->id; ?>">klik hier
                                </a>
                            </div>
                        <?php } ?>
                    </div>
                </div>
                <!-- Gallery navigation and description -->
                <div class="tm-col tm-gallery-right">
                    <h2 class="tm-color-primary tm-mt-35 tm-page-title">Artikels</h2>
                    <div class="tm-gallery-right-inner">
                        <ul class="tm-gallery-links">

                            <p>
                                Hier kan je alle artikelen vinden, deze worden elke dag veranderd maar
                                u kunt de oude nogsteeds opzoeken
                            </p>
                            <p>
                                Proin lacus enim, finibus sed magna a,
                                molestie lacinia est. Maecenas id dolor
                                lorem. Donec sodales ex velit.
                            </p>
                    </div>
                </div>
            </div>
        </div>
        <!-- PROFILE PAGE -->
        <div id="testimonials" class="popup mfp-with-anim mfp-hide tm-bg-gray">
            <a href="#" class="tm-close-popup">
                return home
                <i class="fas fa-times"></i>
            </a>
            <div class="tm-testimonials-inner">
                <h2 class="tm-color-gray tm-testimonial-col tm-page-title">Aanmelden</h2>
                <div class="tm-row tm-testimonial-row">
                    <!-- Upper part -->
                    <p>Klik <a href="../index.php">hier</a> om u aan te melden.</p>

                </div>
            </div>            
        </div>
        <!-- Contact Page -->
        <!-- Contact Page -->
        <div id="contact" class="popup mfp-with-anim mfp-hide tm-bg-gray">
            <a href="#" class="tm-close-popup">
                return home
                <i class="fas fa-times"></i>
            </a>
            <h2 class="tm-contact-col tm-color-primary tm-page-title tm-mb-40">Contact Us</h2>
            <div class="tm-row tm-contact-row">
                <div class="tm-col tm-contact-col">
                    <!-- Contact Form-->
                    <form action="classes/create.php" method="post">
                        Voornaam<br>
                        <label>
                            <input type="text" class="form-control" name="voornaam" id="voornaam" size="50">
                        </label><br><br>
                        Achternaam<br>
                        <label>
                            <input type="text" class="form-control" name="achternaam" id="achternaam" size="100">
                        </label><br><br>
                        Email<br>
                        <label>
                            <input type="text" class="form-control" name="email" id="email" size="100">
                        </label><br>
                        Telefoonnummer<br>
                        <label>
                            <input type="text" class="form-control" name="telefoonnummer" id="telefoonnummer" size="100">
                        </label><br>
                        <label>
                            Inzending<br>
                            <input type="text" class="form-control" name="inzending" id="inzending" size="100">
                        </label> <br>
                        <input type="submit" class="tm-btn" name="btnSubmit" value="Voer het product in">
                        <br>
                    </form>
                </div>
            </div>
            <div class="tm-col tm-contact-col tm-contact-col-r">
                <!-- Map -->
                <br>
                <div class="mapouter tm-mb-40">
                    <div class="gmap_canvas">
                        <iframe width="100%" height="520" id="gmap_canvas"
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4528.850674645962!2d4.546321648786219!3d51.95182740711822!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c5cd3c66c593ad%3A0x37ff53ecda71ac07!2sTechniek%20College%20Rotterdam!5e0!3m2!1snl!2snl!4v1642757542551!5m2!1snl!2snl"
                                frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
                    </div>
                </div>

                <!-- Address -->
                <address class="tm-mb-40">
                    Alexanderstraat 55
                </address>

                <!-- Links -->
                <ul class="tm-contact-links">
                    <li>
                        <a href="tel:0100200340">
                            <i class="fas fa-phone tm-contact-link-icon"></i>
                            Tel: 010-020-0340
                        </a>
                    </li>
                    <li>
                        <a href="mailto:info@company.com">
                            <i class="fas fa-at tm-contact-link-icon"></i>
                            Email: info@company.com
                        </a>
                    </li>
                    <li>
                        <a href="https://www.company.com">
                            <i class="fas fa-link tm-contact-link-icon"></i>
                            URL: www.company.com
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    </div>
        </div>
    </div>

    <footer class="tm-footer">
</footer>

    <script src="../js/jquery-3.4.1.min.js"></script>
    <script src="../js/imagesloaded.pkgd.min.js"></script>
    <script src="../js/isotope.pkgd.min.js"></script>
    <script src="../js/jquery.magnific-popup.min.js"></script>
    <script src="../js/templatemo-script.js"></script>
</body>
</html>