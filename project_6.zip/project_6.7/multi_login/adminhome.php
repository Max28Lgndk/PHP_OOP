<?php
    include "../database/db_connect.php";
    include "../database/workforce.php";

    $database = new Workforce();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project 6</title>
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../fontawesome/css/all.min.css">
    <link rel="stylesheet" href="../css/magnific-popup.css">
    <link rel="stylesheet" href="../css/style.css">

</head>
<body>
<header class="tm-site-header">
    <h1 class="tm-mt-0 tm-mb-15"><span class="tm-color-primary">ADMIN Nederlands</span> <span class="tm-color-gray-2">Nieuws</span></h1>
    <em class="tm-tagline tm-color-light-gray">Uw nieuws op één plek</em>
</header>

<!-- Photo banner 400 px height -->
<div id="tm-video-container">
    <img id="tm-video" src="../img/Skyline-Rotterdam.jpg">
    <i id="tm-video-control-button" class="fas fa-pause"></i>
</div>
<div class="tm-container">
    <nav class="tm-main-nav">
        <ul id="inline-popups"
            <li class="tm-nav-item">
                <a href="#artikels" data-effect="mfp-move-from-top" class="tm-nav-link" id="tm-gallery-link">
                    Artikels
                    <i class="far fa-3x fa-images"></i>
                </a>
            </li>
            <li class="tm-nav-item">
                <a href="#intro" data-effect="mfp-move-from-top" class="tm-nav-link">
                    Update
                    <i class="fas fa-3x fa-water"></i>
                </a>
            </li>
            <li class="tm-nav-item">
                <a href="#create-artikel" data-effect="mfp-move-from-top" class="tm-nav-link">
                    create
                    <i class="far fa-3x fa-smile"></i>
                </a>
            </li>
            <li class="tm-nav-item">
                <a href="#delete" data-effect="mfp-move-from-top" class="tm-nav-link">
                    Delete
                    <i class="far fa-3x fa-comments"></i>
                </a>
            </li>
        </ul>
    </nav>

    <!-- update  -->
    <div id="intro" class="popup mfp-with-anim mfp-hide tm-bg-gray">
        <a href="#" class="tm-close-popup">
            return home
            <i class="fas fa-times"></i>
        </a>
        <!-- update artikel form -->
        <div class="container">
            <form action="../database/update.php" method="post">
                ID<br>
                <label>
                    <input type="number" name="id" size="50">
                </label><br><br>
                Titel<br>
                <label>
                    <input type="text" name="txtTitel" size="50">
                </label><br><br>

                Content<br>
                <label>
                    <input type="text" name="txtContent" size="100">
                </label><br><br>

                <input type="submit" name="btnSubmit" value="Voer het product in">

            </form>
        </div>
        <!-- Artikel page -->
        <div id="artikels" class="popup mfp-with-anim mfp-hide tm-bg-gray">
            <a href="#" class="tm-close-popup">
                return home
                <i class="fas fa-times"></i>
            </a>
            <div class="tm-row tm-gallery-row">
                <div class="tm-gallery">
                    <div class="tm-gallery-container">
                        <?php foreach($database->getArtikelen() as $artikel) { ?>

                        <div class="tm-gallery-item" ><?php echo $artikel->titel;
                            ?>
                            <a href="../crud-artikel/artikel.php?id=<?php echo $artikel->id; ?>">klik hier
                            </a>
                        </div>
<?php } ?>
                    </div>
                </div>
                <!-- Gallery navigation and description -->
                <div class="tm-col tm-gallery-right">
                    <h2 class="tm-color-primary tm-mt-35 tm-page-title">Artikels</h2>
                    <div class="tm-gallery-right-inner">
                        <ul class="tm-gallery-links">

                            <p>
                                Hier kan je alle artikelen vinden, deze worden elke dag veranderd maar
                                u kunt de oude nogsteeds opzoeken
                            </p>
                            <p>
                                Proin lacus enim, finibus sed magna a,
                                molestie lacinia est. Maecenas id dolor
                                lorem. Donec sodales ex velit.
                            </p>
                    </div>
                </div>
            </div>
        </div>
        <!-- create -->
        <div id="create-artikel" class="popup mfp-with-anim mfp-hide tm-bg-gray">
            <a href="#" class="tm-close-popup">
                return home
                <i class="fas fa-times"></i>
            </a>
            <div class="tm-testimonials-inner">
                <h2 class="tm-color-gray tm-testimonial-col tm-page-title">Artikel aanmaken</h2>
                <div class="tm-row tm-testimonial-row">
                    <!-- Upper part -->
                    <p>Voer hier het artikel informatie in.</p>
                    <!-- create Form-->
                    <form id="artikel-form" action="../database/create-artikelen.php" method="POST" class="tm-contact-form">
                        <div class="form-group">
                            <input type="text" name="txtTitel" class="form-control rounded-0" placeholder="Titel" required />
                        </div>
                        <div class="form-group">
                            <textarea rows="8" name="txtContent" class="form-control rounded-0" placeholder="Content" required=></textarea>
                        </div>

                        <div class="form-group tm-text-right">
                            <button type="submit" class="tm-btn tm-btn-primary">Plaats artikel</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- delete Page -->
    <div id="delete" class="popup mfp-with-anim mfp-hide tm-bg-gray">
        <a href="#" class="tm-close-popup">
            return home
            <i class="fas fa-times"></i>
        </a>
        <h2 class="tm-contact-col tm-color-primary tm-page-title tm-mb-40"></h2>
        <div class="tm-row tm-contact-row">
            <div class="tm-col tm-contact-col">
                <!-- delete Form-->
                <form action="../database/delete.php" method="post">
                    ID<br>
                    <label>
                        <input type="number" name="delid" size="50">
                    </label><br><br>
                    <input type="submit" name="btnSubmit" value="Voer het product in">

                </form>
            </div>
        </div>
    </div>
</div>

<footer class="tm-footer">
</footer>

<script src="../js/jquery-3.4.1.min.js"></script>
<script src="../js/imagesloaded.pkgd.min.js"></script>
<script src="../js/isotope.pkgd.min.js"></script>
<script src="../js/jquery.magnific-popup.min.js"></script>
<script src="../js/templatemo-script.js"></script>
</body>
</html>