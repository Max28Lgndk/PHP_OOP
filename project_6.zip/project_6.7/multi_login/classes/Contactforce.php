<?php
class Contactforce
{
    private PDO $conn;

    public function __construct($hst = 'localhost', $dbn = 'project_6', $chr = 'utf8mb4', $un = 'root', $up = '')
    {
        $dsn = "mysql:host=$hst;dbname=$dbn;charset=$chr";
        $this->conn = new PDO("mysql:host=localhost;dbname=project_6;charset=utf8mb4", $un, $up);
    }

    public function createVoornaam($nwVoornaam, $nwAchternaam, $nwEmail, $nwTelefoonnummer, $nwInzending): string
    {
        require_once "dbh.classes.php";
        $stmt = $this->conn->prepare("INSERT INTO inzendingen (voornaam, achternaam, email, telefoonnummer, inzending) VALUE (?, ?, ?, ?, ?)");
        $stmt->execute([$nwVoornaam, $nwAchternaam, $nwEmail, $nwTelefoonnummer, $nwInzending]);
        return $this->conn->lastInsertId();
    }
}
