<?php

class LoginContrl extends Login {

    private $uid;
    private $pwd;

    public function __construct($uid, $pwd){
        $this->uid =$uid;
        $this->pwd =$pwd;
    }

    public function loginUser() {
        if($this->emptyInput() == false) {
            // echo "Invalid!";
            header("location: ../index.php?error=emptyinput");
            exit();
        }

        if($this->adminCheck() == true) {
            // echo "You are an admin";
            header("location: ../adminhome.php?error=admin");
            exit();
        }
        $this->getUser($this->uid, $this->pwd);
    }

    private function emptyInput() {
        $result;
        if(empty($this->uid) || empty($this->pwd)) {
            $result = false;
        }
        else{
            $result = true;
        }
        return $result;
    }
    private function adminCheck() {
        $result;
        if ($this->uid == "admin") {
            $result = true;
        }
        else {
            $result = false;
        }
        return $result;
    }

}
