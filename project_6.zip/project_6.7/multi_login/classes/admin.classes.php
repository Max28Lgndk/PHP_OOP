<?php
//    class Perm{
//
//    include "../classes/dbh.classes.php";
//
//        public function hasPermission($key)
//        {
//            $group = $this->_db->get('groups', array('id', '=', $this->data()->group));
//        }
//
//
//    }
//
//
//
////if ($logged_in_gebruiker['gebruiker_type'] == 'admin') {
//////
//////                $_SESSION['gebruiker'] = $logged_in_gebruiker;
//////                $_SESSION['success']  = "U bent nu ingelogd";
//////                header('location: admin/home.php');
//////            }else{
//////                $_SESSION['user'] = $logged_in_gebruiker;
//////                $_SESSION['success']  = "U bent nu ingelogd";
//////                header('location: ../Project_P5/home.php');
//////            }
//////        }else {
//////            array_push($errors, "Verkeerde gebruikersnaam/wachtwoord combinatie");
//////        }
//////    }
//////}