<?php
require_once('dbh.classes.php');
require_once("Contactforce.php");
$creatVoornaam = new Contactforce();
if (true) {
    $nwVoornaam = "geen idee waarom dit hier moet staan maar anders werkt het niet titel";
    $nwAchternaam = "geen idee waarom dit hier moet staan maar anders werkt het niet content";
    $nwVoornaam = $_POST['voornaam'];
    $nwAchternaam = $_POST['achternaam'];
    $nwEmail = $_POST['email'];
    $nwTelefoonnummer = $_POST['telefoonnummer'];
    $nwInzending = $_POST['inzending'];
    echo $nwVoornaam;
    echo $nwAchternaam;
    echo $nwEmail;
    echo $nwTelefoonnummer;
    echo $nwInzending;
    $creatVoornaam->createVoornaam($nwVoornaam, $nwAchternaam, $nwEmail, $nwTelefoonnummer, $nwInzending);
}
