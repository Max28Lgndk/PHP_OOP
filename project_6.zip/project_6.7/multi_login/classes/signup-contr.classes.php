<?php

class SignupContrl extends Signup {

    private $uid;
    private $pwd;
    private $pwdRepeat;
    private $email;

    public function __construct($uid, $pwd, $pwdRepeat, $email){
        $this->uid =$uid;
        $this->pwd =$pwd;
        $this->pwdRepeat =$pwdRepeat;
        $this->email =$email;
    }

    public function signupUser() {
        if($this->emptyInput() == false) {
            // echo "Invalid!";
            header("location: ../index.php?error=emptyinput");
            exit();
        }
        if($this->pwdMatch() == false) {
            // echo "Password does not match!";
            header("location: ../index.php?error=passwordmatch");
            exit();
        }
        if($this->uidTakenCheck() == false) {
            // echo "Username or Email taken!";
            header("location: ../index.php?error=useroremailtaken");
            exit();
        }
        if($this->adminCheck() == true) {
            // echo "You are an admin!";
            header("location: ../adminhome.php?error=admin");
            exit();
        }

        $this->setUser($this->uid, $this->pwd, $this->email);

    }

    private function emptyInput() {
        $result;
        if(empty($this->uid) || empty($this->pwd) || empty($this->pwdRepeat) || empty($this->email)) {
            $result = false;
        }
        else{
            $result = true;
        }
        return $result;
    }

    private function pwdMatch() {
        $result;
        if ($this->pwd !== $this->pwdRepeat) {
            $result = false;
        }
        else {
            $result = true;
        }
        return $result;
    }

    private function uidTakenCheck() {
        $result;
        if (!$this->checkUser($this->uid, $this->email)) {
            $result = false;
        }
        else {
            $result = true;
        }
        return $result;
    }
    private function adminCheck() {
        $result;
        if ($this->uid == "admin") {
            $result = true;
        }
        else {
            $result = false;
        }
        return $result;
    }

}