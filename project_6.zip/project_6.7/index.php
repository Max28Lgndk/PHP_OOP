<?php session_start();?>

<html lang="en">
<head>
    <title>Inlog pagina</title>
    <meta name="author" content="Milan Groeneweg">
    <link rel="stylesheet" type="text/css" href="multi_login/style.css">
</head>
<body>

<div class="welkom">
    <h1 id="welkom">Nederlands Nieuws</h1>
    <h4 id="welkomh4">Alle laatste Nederlande nieuwtjes!</h4>
    <h5 id="welkom5">Login of maak een account aan</h5>
</div>

<!--Pagina voor de gebruiker om een account aan te maken-->
<div class="registreer">
<div class="header">
    <h2>Registreer</h2>
</div>
<form method="post" action="multi_login/includes/signup.inc.php">
    <div class="input-group">
        <label>Gebruikersnaam
        <input type="text" name="uid"></label>
    </div>
    <div class="input-group">
        <label>Wachtwoord
        <input type="password" name="pwd"></label>
    </div>
    <div class="input-group">
        <label>Wachtwoord bevestigen
        <input type="password" name="pwdRepeat"></label>
    </div>
    <div class="input-group">
        <label>Email
        <input type="text" name="email"></label>
    </div>
    <div class="input-group">
        <button type="submit" class="btn" name=submit>Registreer</button>
    </div>
</form>
</div>

<!--Hier kan de gebruiker inloggen -->
<div class="login">
    <div class="header">
        <h2>Login</h2>
    </div>
    <form method="post" action="multi_login/includes/login.inc.php">
        <div class="input-group">
            <label>Gebruikersnaam
            <input type="text" name="uid"></label>
        </div>
        <div class="input-group">
            <label>Wachtwoord
            <input type="password" name="pwd"></label>
        </div>
        <div class="input-group">
            <button type="submit" class="btn" name="submit">Log in</button>
        </div>
    </form>
</body>
</html>
</div>