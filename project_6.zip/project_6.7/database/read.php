<?php
    require_once('db_connect.php');
    require_once("workforce.php");

    if(isset($_GET['id'])) {
        $database = new Workforce();
        $artikelId = $_GET['id'];
        $eenArtikel = $database->getArtikel($artikelId);
        foreach ($database->getArtikel($artikelId) as $eenArtikel => $artikel) {
            echo $artikel . "<br>";
    }}







