<?php

class Workforce
{
    public $conn;


    public function __construct($hst='localhost', $dbn='project_6', $chr='utf8mb4', $un='root', $up='') {
        $dsn = "mysql:host=$hst;dbname=$dbn;charset=$chr";

        $this->conn = new PDO("mysql:host=localhost;dbname=project_6;charset=utf8mb4", $un, $up);
    }

    public function getArtikelen()
    {
        $stmt = $this->conn->query("SELECT * FROM artikelen");
        return $stmt->fetchAll(PDO::FETCH_OBJ);
    }


    public function getArtikel($artikelId) {
        $stmt = $this->conn->prepare("SELECT * FROM artikelen WHERE id = :artid");
        $stmt->execute(["artid" => $artikelId]);
        return $stmt->fetch(PDO::FETCH_OBJ);
    }

    public function delArtikel($artikel_id) {
        $stmt = $this->conn->prepare("DELETE FROM artikelen WHERE id = :aid");
        $stmt->execute(["aid" => $artikel_id]);
    }

    public function createArtikel($nwTitel,$nwContent)
    {
        $stmt = $this->conn->prepare("INSERT INTO artikelen (titel, content) VALUES( ?, ?)");
        $stmt->execute([$nwTitel,$nwContent]);
    }

    public function updateArtikel($uTitel, $uContent, $uId ) {
        $stmt = $this->conn->prepare("UPDATE artikelen SET titel = :t, content = :c WHERE id = :i");
        $stmt->execute([ "t" => $uTitel, "c" => $uContent, "i" => $uId]);
    }
}

//$jarno = new Workforce();
//
//foreach($jarno->getArtikelen() as $eenArtikel) {
//    echo "<br>".$eenArtikel->id . " " . $eenArtikel->titel . " " . $eenArtikel->content;
//}
//
//echo "<h1>Een artikel met nummer 11:</h1>";
//$art = $jarno->getArtikel(11);
//if($art) {
//    echo "De titel van het artikel is ".$art->titel;
//} else {
//    echo "Dat artikel is er niet...";
//}
//
//$jarno->delArtikel(11);
//
//echo "ID: " . $jarno->createArtikel("Ik ben de nieuwe TITEL", "Ik de de CONTENT van het nieuwe artikel");
//
//foreach($jarno->getArtikelen() as $eenArtikel) {
//    echo "<br>".$eenArtikel->id . " " . $eenArtikel->titel . " " . $eenArtikel->content;
//}
//
//$jarno->updateArtikel("Het is fraai, zei de Kraai", "Het is een mooi voorbeeld van OOP", 25);
//
//foreach($jarno->getArtikelen() as $eenArtikel) {
//    echo "<br>".$eenArtikel->id . " " . $eenArtikel->titel . " " . $eenArtikel->content;
//}