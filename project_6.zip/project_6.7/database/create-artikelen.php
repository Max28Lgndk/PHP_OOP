<?php

    require_once('db_connect.php');
    require_once("workforce.php");

    $creaArt = new Workforce();
if (true) {
    $nwTitel = "geen idee waarom dit hier moet staan maar anders werkt het niet titel";
    $nwContent = "geen idee waarom dit hier moet staan maar anders werkt het niet content";
    $nwTitel = $_POST['txtTitel'];
    $nwContent = $_POST['txtContent'];
    echo $nwTitel;

    echo $nwContent;
    $creaArt->createArtikel($nwTitel , $nwContent);
    header("location: ../multi_login/adminhome.php");
}