<?php
    if(isset($_GET['cmd']) && isset($_GET['id'])) {

        require_once('db_connect.php');
        // update
        if($_GET['cmd'] == 'upd') {
            header("location: login-update.php?id=" . $_GET['id']);
        }
        // delete
        else if($_GET['cmd'] == 'del')  {
            $stmt = $conn->prepare("DELETE FROM artikelen WHERE id = :id");
            $stmt->execute(["id" => $_GET['id']]);
            header("location: read.php");
        }
        //create
        if($_GET['cmd'] == 'cre') {
            header("location: create_artikelen.php");
        }
    }