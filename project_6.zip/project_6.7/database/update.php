<?php

if(isset($_POST['btnSubmit'])){
    require_once('db_connect.php');
    require_once("workforce.php");
    $updArt = new Workforce();

    global $conn;

    $updArt->updateArtikel( uTitel: $_POST['txtTitel'],uContent: $_POST['txtContent'], uId: $_POST['id']);
    header("location: ../multi_login/adminhome.php");
}

?>


