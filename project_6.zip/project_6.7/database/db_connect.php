<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_6";
$hoi =1;

// Create connection *
$conn = new PDO("mysql:host=$servername;dbname=$dbname;", $username, $password);