<?php
require_once('db_connect.php');
require_once("workforce.php");

global $conn;
if(isset($_POST['btnSubmit'])) {
    $delArt = new Workforce();

    $delArt->delArtikel( artikel_id: $int_value = intval( $_POST['delid']) );
    header("location: ../multi_login/adminhome.php");
}
